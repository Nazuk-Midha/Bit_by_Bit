from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# List of space-related words
words = ['planet', 'star', 'galaxy', 'astronaut', 'nebula', 'comet', 'alien', 'rocket', 'orbit']

# Select a random word from the list
word = random.choice(words)

# Initialize game state
guessed_letters = set()
tries = 7

@app.route('/')
def index():
    return render_template('index.html', word_length=len(word), tries=tries)

@app.route('/guess', methods=['POST'])
def guess():
    global tries
    global guessed_letters
    guess = request.json['guess']

    if guess not in guessed_letters:
        guessed_letters.add(guess)
        if guess not in word:
            tries -= 1

    # Check if player won
    if all(letter in guessed_letters for letter in word):
        return jsonify({'win': True, 'word': word})
    
    # Check if player lost
    if tries == 0:
        return jsonify({'win': False, 'word': word})

    return jsonify({'win': None})

if __name__ == '__main__':
    app.run(debug=True)
